import os

class Principal:
    def __init__(self, username):
        self.username = username
        self.files = {
            "course": "courses.txt",
            "staff": "staff.txt",
            "student": "students.txt",
            "notice": "notices.txt"
        }

    def menu(self):
        while True:
            print(f"\n--- Principal Menu ({self.username}) ---")
            print("1. Change Password")
            print("2. Course Management")
            print("3. Staff Management")
            print("4. Student Management")
            print("5. Notice Management")
            print("6. Logout")

            ch = input("Choose: ")
            if ch == '1':
                self.change_password()
            elif ch == '2':
                self.manage_section("course", ["ID", "Name", "Duration", "Fees"])
            elif ch == '3':
                self.manage_section("staff", ["ID", "Name", "Subject", "Phone", "Email"])
            elif ch == '4':
                self.manage_section("student", ["ID", "Name", "Course", "Phone", "Email"])
            elif ch == '5':
                self.manage_section("notice", ["ID", "Title", "Description", "Date"])
            elif ch == '6':
                print("Logging out...")
                break
            else:
                print("Invalid choice!")

    def manage_section(self, section, fields):
        file = self.files[section]
        while True:
            print(f"\n{section.title()} Actions: 1.Add 2.Update 3.Delete 4.ShowAll 5.Search 6.Back")
            ch = input("Choose: ")

            if ch == '1':
                self.add_record(file, fields, section)
            elif ch == '2':
                self.update_record(file)
            elif ch == '3':
                self.delete_record(file, section)
            elif ch == '4':
                self.show_all(file)
            elif ch == '5':
                self.search_record(file)
            elif ch == '6':
                break
            else:
                print("Invalid choice!")

    def add_record(self, file, fields, section):
        data = [input(f"Enter {f}: ") for f in fields]
        record_id = data[0]

        # Check for duplicate ID
        if os.path.exists(file):
            with open(file, "r") as f:
                for line in f:
                    if line.strip().split("|")[0] == record_id:
                        print("❌ Error: ID already exists. Record not added.")
                        return

        # Add record
        record_line = "|".join(data) + "\n"
        with open(file, "a") as f:
            f.write(record_line)
        print("✅ Record added successfully.")

        # Auto-create login for students
        if section == "student":
            self.create_login(data[0], data[1], "student", "student123")

        # Auto-create login for staff
        elif section == "staff":
            self.create_login(data[0], data[1], "staff", "staff123")

    def create_login(self, user_id, name, role, default_pass):
        username = name.replace(" ", "").lower()
        credentials_line = f"{username}|{default_pass}|{role}|{user_id}\n"

        # Check if already exists
        exists = False
        if os.path.exists("credentials.txt"):
            with open("credentials.txt", "r") as cred:
                for line in cred:
                    parts = line.strip().split("|")
                    if len(parts) > 0 and parts[0] == username:
                        exists = True
                        break

        if not exists:
            with open("credentials.txt", "a") as cred:
                cred.write(credentials_line)
            print(f"🔐 Login created for {role}: {username} (default password: {default_pass})")
        else:
            print(f"ℹ️ {role.title()} login '{username}' already exists — skipped adding.")

    def update_record(self, file):
        sid = input("Enter ID to update: ")
        if not os.path.exists(file):
            print("File not found!")
            return
        lines = open(file, "r").readlines()
        found = False
        with open(file, "w") as f:
            for line in lines:
                parts = line.strip().split("|")
                if parts[0] == sid:
                    found = True
                    print("Enter new details:")
                    new_line = "|".join(input(f"Enter new {field}: ") for field in parts) + "\n"
                    f.write(new_line)
                    print("✅ Record updated successfully.")
                else:
                    f.write(line)
        if not found:
            print("Record not found!")

    def delete_record(self, file, section):
        sid = input("Enter ID to delete: ")
        if not os.path.exists(file):
            print("File not found!")
            return

        lines = open(file, "r").readlines()
        with open(file, "w") as f:
            for line in lines:
                if not line.startswith(sid + "|"):
                    f.write(line)
        print("🗑️ Record deleted (if existed).")

        # Also delete login if student or staff record deleted
        if section in ["student", "staff"]:
            if os.path.exists("credentials.txt"):
                with open("credentials.txt", "r") as cred:
                    creds = cred.readlines()
                with open("credentials.txt", "w") as cred:
                    for line in creds:
                        parts = line.strip().split("|")
                        if len(parts) == 4 and parts[3] != sid:
                            cred.write(line)
                print(f"🗝️ Associated {section} login removed (if existed).")

    def show_all(self, file):
        try:
            with open(file, "r") as f:
                data = f.readlines()
                if not data:
                    print("No records found.")
                for d in data:
                    print(d.strip())
        except FileNotFoundError:
            print("File not found!")

    def search_record(self, file):
        key = input("Enter keyword to search: ")
        try:
            with open(file, "r") as f:
                found = False
                for line in f:
                    if key.lower() in line.lower():
                        print(line.strip())
                        found = True
                if not found:
                    print("No matching record found.")
        except FileNotFoundError:
            print("File not found!")

    def change_password(self):
        username = self.username
        new_pass = input("Enter new password: ")
        lines = open("credentials.txt").readlines()
        with open("credentials.txt", "w") as f:
            for line in lines:
                parts = line.strip().split("|")
                if parts[0] == username and parts[2] == "principal":
                    parts[1] = new_pass
                    f.write("|".join(parts) + "\n")
                    print("🔒 Password changed successfully!")
                else:
                    f.write(line)



